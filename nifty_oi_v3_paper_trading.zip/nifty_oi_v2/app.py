"""
OI Terminal v3.0 — Paper Trading Edition
=========================================
Features:
- Nifty 50 + Bank Nifty Live OI
- OI Activity with Timestamps
- Paper Trading Platform (Virtual Money)
- 5 Ready Strategies (OI-based)
- Auto Paper Trade Execution
- P&L Tracking, Trade Log
"""

from flask import Flask, redirect, request, jsonify, send_from_directory
from kiteconnect import KiteConnect
import os, time, threading, json
from datetime import datetime, date
from collections import deque

app = Flask(__name__, static_folder='static')

# ── CREDENTIALS ──
API_KEY    = "YOUR_API_KEY_HERE"
API_SECRET = "YOUR_API_SECRET_HERE"
kite       = KiteConnect(api_key=API_KEY)
TOKEN_FILE = "access_token.txt"

# ── INSTRUMENT CACHE ──
_instruments_cache = []
_instruments_date  = None
_instruments_lock  = threading.Lock()
_sym_map           = {}
_sym_map_lock      = threading.Lock()

# ── CONFIG ──
SPOT_KEYS  = {"NIFTY": "NSE:NIFTY 50", "BANKNIFTY": "NSE:NIFTY BANK"}
STEP       = {"NIFTY": 50, "BANKNIFTY": 100}
STRIKES_N  = 15

# ── OI STATE ──
pcr_history   = {"NIFTY": deque(maxlen=30), "BANKNIFTY": deque(maxlen=30)}
price_history = {"NIFTY": deque(maxlen=6),  "BANKNIFTY": deque(maxlen=6)}
oi_cache      = {"NIFTY": {}, "BANKNIFTY": {}}
last_updated  = {"NIFTY": 0,  "BANKNIFTY": 0}
last_snapshot = {"NIFTY": {}, "BANKNIFTY": {}}
last_snap_time= {"NIFTY": 0,  "BANKNIFTY": 0}

# ── ACTIVITY LOG WITH TIMESTAMPS ──
activity_log = {"NIFTY": deque(maxlen=100), "BANKNIFTY": deque(maxlen=100)}

# ════════════════════════════════════════
#  PAPER TRADING ENGINE
# ════════════════════════════════════════
PAPER_FILE = "paper_trades.json"

def load_paper_state():
    if os.path.exists(PAPER_FILE):
        try:
            with open(PAPER_FILE) as f:
                return json.load(f)
        except:
            pass
    return {
        "capital":        100000,   # Starting capital ₹1,00,000
        "available":      100000,
        "total_pnl":      0,
        "trades":         [],       # All completed trades
        "open_positions": [],       # Active positions
        "daily_pnl":      {},       # date -> pnl
        "stats": {
            "total_trades": 0,
            "wins": 0,
            "losses": 0,
            "max_win": 0,
            "max_loss": 0,
        }
    }

def save_paper_state(state):
    with open(PAPER_FILE, "w") as f:
        json.dump(state, f, indent=2)

paper_state = load_paper_state()
paper_lock  = threading.Lock()

# ════════════════════════════════════════
#  5 READY STRATEGIES
# ════════════════════════════════════════
STRATEGIES = {
    "PCR_REVERSAL": {
        "name": "PCR Reversal",
        "description": "Buy when PCR > 1.3 (extreme put writing = bullish reversal). Sell when PCR < 0.7.",
        "risk":   "Low",
        "target_pts": 80,
        "sl_pts":     40,
        "rr":         "1:2",
    },
    "CALL_WALL_BREAKOUT": {
        "name": "Call Wall Breakout",
        "description": "Buy when price breaks above Call Wall with Put OI building. Strong momentum trade.",
        "risk":   "Medium",
        "target_pts": 120,
        "sl_pts":     60,
        "rr":         "1:2",
    },
    "PUT_WALL_BOUNCE": {
        "name": "Put Wall Bounce",
        "description": "Buy when price tests Put Wall and bounces. Put writers defend the level.",
        "risk":   "Low",
        "target_pts": 80,
        "sl_pts":     40,
        "rr":         "1:2",
    },
    "LONG_BUILDUP_RIDE": {
        "name": "Long Buildup Ride",
        "description": "Enter long when 3+ strikes show Long Buildup simultaneously. Ride the momentum.",
        "risk":   "Medium",
        "target_pts": 100,
        "sl_pts":     50,
        "rr":         "1:2",
    },
    "SHORT_COVER_SQUEEZE": {
        "name": "Short Cover Squeeze",
        "description": "Buy when 3+ strikes show Short Covering. Shorts being squeezed = sharp up move.",
        "risk":   "High",
        "target_pts": 150,
        "sl_pts":     75,
        "rr":         "1:2",
    },
}

def check_strategy_signals(symbol, pcr, spot, call_wall, put_wall, activities, chg):
    """Check all strategies and return triggered ones."""
    signals = []
    now_str = datetime.now().strftime("%H:%M:%S")
    step    = STEP[symbol]
    atm     = round(spot / step) * step

    # 1. PCR REVERSAL
    if pcr > 1.3:
        signals.append({
            "strategy": "PCR_REVERSAL",
            "direction": "BUY",
            "entry": spot,
            "target": round(spot + 80),
            "sl": round(spot - 40),
            "reason": f"PCR {pcr:.2f} — extreme put writing, bullish reversal expected",
            "confidence": "High" if pcr > 1.5 else "Medium",
            "time": now_str,
        })
    elif pcr < 0.7:
        signals.append({
            "strategy": "PCR_REVERSAL",
            "direction": "SELL",
            "entry": spot,
            "target": round(spot - 80),
            "sl": round(spot + 40),
            "reason": f"PCR {pcr:.2f} — extreme call writing, bearish reversal expected",
            "confidence": "High" if pcr < 0.5 else "Medium",
            "time": now_str,
        })

    # 2. CALL WALL BREAKOUT
    if call_wall and spot > call_wall - 30 and chg > 0:
        signals.append({
            "strategy": "CALL_WALL_BREAKOUT",
            "direction": "BUY",
            "entry": spot,
            "target": round(spot + 120),
            "sl": round(spot - 60),
            "reason": f"Price {spot:.0f} attacking Call Wall {call_wall} — breakout potential",
            "confidence": "Medium",
            "time": now_str,
        })

    # 3. PUT WALL BOUNCE
    if put_wall and spot < put_wall + 50 and spot > put_wall - 30:
        signals.append({
            "strategy": "PUT_WALL_BOUNCE",
            "direction": "BUY",
            "entry": spot,
            "target": round(spot + 80),
            "sl": round(spot - 40),
            "reason": f"Price {spot:.0f} testing Put Wall {put_wall} — bounce expected",
            "confidence": "High",
            "time": now_str,
        })

    # 4. LONG BUILDUP RIDE
    lb_count = sum(1 for a in activities if a["type"] == "LONG_BUILDUP")
    if lb_count >= 2:
        signals.append({
            "strategy": "LONG_BUILDUP_RIDE",
            "direction": "BUY",
            "entry": spot,
            "target": round(spot + 100),
            "sl": round(spot - 50),
            "reason": f"{lb_count} strikes showing Long Buildup — strong bullish momentum",
            "confidence": "High" if lb_count >= 4 else "Medium",
            "time": now_str,
        })

    # 5. SHORT COVER SQUEEZE
    sc_count = sum(1 for a in activities if a["type"] == "SHORT_COVER")
    if sc_count >= 2:
        signals.append({
            "strategy": "SHORT_COVER_SQUEEZE",
            "direction": "BUY",
            "entry": spot,
            "target": round(spot + 150),
            "sl": round(spot - 75),
            "reason": f"{sc_count} strikes showing Short Covering — squeeze rally incoming",
            "confidence": "High" if sc_count >= 3 else "Medium",
            "time": now_str,
        })

    return signals

# ════════════════════════════════════════
#  AUTO PAPER TRADE EXECUTION
# ════════════════════════════════════════
def auto_execute_paper_trade(symbol, signal, spot):
    """Automatically execute a paper trade based on strategy signal."""
    global paper_state
    with paper_lock:
        state = paper_state

        # Check if same strategy already has open position
        existing = [p for p in state["open_positions"]
                    if p["symbol"]==symbol and p["strategy"]==signal["strategy"]]
        if existing:
            return None  # Don't double-enter same strategy

        # Position sizing: risk 2% of capital per trade
        risk_amount  = state["capital"] * 0.02
        sl_pts       = abs(signal["entry"] - signal["sl"])
        qty          = max(1, int(risk_amount / max(sl_pts, 1)))
        qty          = min(qty, 75)  # cap at 75 (1 lot Nifty)

        position = {
            "id":        f"PT{int(time.time()*1000)}",
            "symbol":    symbol,
            "strategy":  signal["strategy"],
            "direction": signal["direction"],
            "entry":     signal["entry"],
            "target":    signal["target"],
            "sl":        signal["sl"],
            "qty":       qty,
            "entry_time":signal["time"],
            "reason":    signal["reason"],
            "confidence":signal["confidence"],
            "status":    "OPEN",
            "pnl":       0,
        }

        state["open_positions"].append(position)
        save_paper_state(state)
        print(f"[PAPER] {signal['direction']} {symbol} @ {signal['entry']} | "
              f"SL:{signal['sl']} TGT:{signal['target']} | Qty:{qty} | {signal['strategy']}")
        return position

def check_exit_paper_trades(symbol, spot):
    """Check if any open positions hit target or SL."""
    global paper_state
    exited = []
    with paper_lock:
        state   = paper_state
        now_str = datetime.now().strftime("%H:%M:%S")
        remaining = []

        for pos in state["open_positions"]:
            if pos["symbol"] != symbol:
                remaining.append(pos)
                continue

            hit_target = (pos["direction"]=="BUY"  and spot >= pos["target"]) or \
                         (pos["direction"]=="SELL" and spot <= pos["target"])
            hit_sl     = (pos["direction"]=="BUY"  and spot <= pos["sl"]) or \
                         (pos["direction"]=="SELL" and spot >= pos["sl"])

            if hit_target or hit_sl:
                exit_price = pos["target"] if hit_target else pos["sl"]
                if pos["direction"] == "BUY":
                    pnl = (exit_price - pos["entry"]) * pos["qty"]
                else:
                    pnl = (pos["entry"] - exit_price) * pos["qty"]

                pnl = round(pnl, 2)
                result = "WIN" if pnl > 0 else "LOSS"

                trade = {**pos,
                    "exit":       exit_price,
                    "exit_time":  now_str,
                    "exit_reason":"TARGET" if hit_target else "STOP LOSS",
                    "pnl":        pnl,
                    "result":     result,
                    "status":     "CLOSED",
                }
                state["trades"].append(trade)
                state["total_pnl"] = round(state["total_pnl"] + pnl, 2)
                state["available"] = round(state["available"] + pnl, 2)

                # Update stats
                state["stats"]["total_trades"] += 1
                if pnl > 0:
                    state["stats"]["wins"]    += 1
                    state["stats"]["max_win"]  = max(state["stats"]["max_win"], pnl)
                else:
                    state["stats"]["losses"]  += 1
                    state["stats"]["max_loss"] = min(state["stats"]["max_loss"], pnl)

                # Daily P&L
                today = str(date.today())
                state["daily_pnl"][today] = round(
                    state["daily_pnl"].get(today, 0) + pnl, 2)

                exited.append(trade)
                print(f"[PAPER] CLOSED {pos['direction']} {symbol} | "
                      f"Entry:{pos['entry']} Exit:{exit_price} | "
                      f"P&L: ₹{pnl} | {result}")
            else:
                # Update unrealised PnL
                if pos["direction"] == "BUY":
                    pos["pnl"] = round((spot - pos["entry"]) * pos["qty"], 2)
                else:
                    pos["pnl"] = round((pos["entry"] - spot) * pos["qty"], 2)
                remaining.append(pos)

        state["open_positions"] = remaining
        if exited:
            save_paper_state(state)
    return exited

# ════════════════════════════════════════
#  INSTRUMENTS
# ════════════════════════════════════════
def get_instruments():
    global _instruments_cache, _instruments_date
    today = date.today()
    with _instruments_lock:
        if _instruments_date == today and _instruments_cache:
            return _instruments_cache
        print(f"[{datetime.now():%H:%M:%S}] Loading NFO instruments...")
        t0 = time.time()
        _instruments_cache = kite.instruments("NFO")
        _instruments_date  = today
        print(f"[{datetime.now():%H:%M:%S}] Loaded {len(_instruments_cache)} in {time.time()-t0:.1f}s")
        _rebuild_sym_map()
        return _instruments_cache

def _rebuild_sym_map():
    global _sym_map
    m = {}
    for inst in _instruments_cache:
        otype = inst["instrument_type"]
        if otype not in ("CE","PE"): continue
        key = f"{inst['name']}|{inst['expiry']}"
        m.setdefault(key,{}).setdefault(inst["strike"],{})[otype] = inst["tradingsymbol"]
    with _sym_map_lock:
        _sym_map = m

def get_nearest_expiry(symbol):
    get_instruments()
    dates = sorted({str(i["expiry"]) for i in _instruments_cache if i["name"]==symbol})
    return dates[0] if dates else None

# ════════════════════════════════════════
#  SPOT
# ════════════════════════════════════════
def get_spot(symbol):
    try:
        key = SPOT_KEYS[symbol]
        q   = kite.quote([key])
        d   = q.get(key,{})
        ltp = d.get("last_price",0)
        cls = d.get("ohlc",{}).get("close",0) or ltp or 1
        return {"last_price":ltp,"change":round(ltp-cls,2),
                "open":d.get("ohlc",{}).get("open",0),
                "high":d.get("ohlc",{}).get("high",0),
                "low": d.get("ohlc",{}).get("low",0),"close":cls}
    except Exception as e:
        print(f"Spot error {symbol}: {e}")
        return {"last_price":0,"change":0,"open":0,"high":0,"low":0,"close":0}

# ════════════════════════════════════════
#  OPTION CHAIN
# ════════════════════════════════════════
def get_chain_fast(symbol):
    try:
        spot_data = get_spot(symbol)
        spot  = spot_data["last_price"] or (24850 if symbol=="NIFTY" else 52000)
        step  = STEP[symbol]
        atm   = round(spot/step)*step
        relevant = set(atm + i*step for i in range(-STRIKES_N, STRIKES_N+1))

        expiry = get_nearest_expiry(symbol)
        if not expiry:
            return {"chain":[],"expiry":"N/A","spot":spot_data}

        map_key = f"{symbol}|{expiry}"
        with _sym_map_lock:
            strike_map = dict(_sym_map.get(map_key,{}))
        if not strike_map:
            get_instruments()
            with _sym_map_lock:
                strike_map = dict(_sym_map.get(map_key,{}))

        trading_syms = [f"NFO:{tsym}"
                        for s in relevant if s in strike_map
                        for tsym in strike_map[s].values()]
        if not trading_syms:
            return {"chain":[],"expiry":expiry,"spot":spot_data}

        quotes = {}
        for j in range(0,len(trading_syms),200):
            try:
                q = kite.quote(trading_syms[j:j+200])
                quotes.update(q)
            except Exception as e:
                print(f"Quote error: {e}")

        chain = {}
        for s in relevant:
            if s not in strike_map: continue
            chain[s] = {"strike":s,"callOI":0,"putOI":0,
                        "callChg":0,"putChg":0,"callLTP":0,"putLTP":0,
                        "call5minChg":0,"put5minChg":0}
            for otype,tsym in strike_map[s].items():
                q    = quotes.get(f"NFO:{tsym}",{})
                oi   = q.get("oi",0)
                ltp  = q.get("last_price",0)
                oi_h = q.get("oi_day_high",oi)
                oi_l = q.get("oi_day_low",oi)
                chg  = round((oi_h-oi_l)/max(oi,1)*100,2)
                if otype=="CE":
                    chain[s]["callOI"]=oi; chain[s]["callLTP"]=ltp; chain[s]["callChg"]=chg
                else:
                    chain[s]["putOI"]=oi;  chain[s]["putLTP"]=ltp;  chain[s]["putChg"]=chg

        result = sorted(chain.values(), key=lambda x:x["strike"])

        now  = time.time()
        snap = last_snapshot[symbol]
        if not snap or now-last_snap_time[symbol] >= 300:
            last_snapshot[symbol]  = {d["strike"]:{"c":d["callOI"],"p":d["putOI"]} for d in result}
            last_snap_time[symbol] = now
        else:
            for d in result:
                prev = snap.get(d["strike"],{})
                d["call5minChg"] = d["callOI"]-prev.get("c",d["callOI"])
                d["put5minChg"]  = d["putOI"] -prev.get("p",d["putOI"])

        try:
            exp_disp = datetime.strptime(expiry,"%Y-%m-%d").strftime("%d %b %Y")
        except:
            exp_disp = str(expiry)

        return {"chain":result,"expiry":exp_disp,"spot":spot_data}
    except Exception as e:
        print(f"Chain error {symbol}: {e}")
        return {"chain":[],"expiry":"N/A","spot":{}}

# ════════════════════════════════════════
#  OI ACTIVITY WITH TIMESTAMPS
# ════════════════════════════════════════
def detect_activity(symbol, chain, spot, prev_spot):
    price_up   = spot > prev_spot if (prev_spot and prev_spot!=spot) else None
    price_down = spot < prev_spot if (prev_spot and prev_spot!=spot) else None
    threshold  = 10000
    now_str    = datetime.now().strftime("%H:%M:%S")
    activities = []

    for d in chain:
        c5,p5   = d["call5minChg"],d["put5minChg"]
        cchg,pchg = d["callChg"],d["putChg"]
        coi,poi = d["callOI"],d["putOI"]

        new_acts = []

        # Method 1: 5-min change + price direction
        if price_up is not None:
            if price_up and p5>threshold and poi>100000:
                new_acts.append({"type":"LONG_BUILDUP","strike":d["strike"],
                    "label":"Long Buildup","detail":f"Put OI +{sfmt(p5)} | Price ↑",
                    "time":now_str,"oi_change":p5})
            if price_down and c5>threshold and coi>100000:
                new_acts.append({"type":"SHORT_BUILDUP","strike":d["strike"],
                    "label":"Short Buildup","detail":f"Call OI +{sfmt(c5)} | Price ↓",
                    "time":now_str,"oi_change":c5})
            if price_down and p5<-threshold:
                new_acts.append({"type":"LONG_UNWIND","strike":d["strike"],
                    "label":"Long Unwinding","detail":f"Put OI {sfmt(p5)} | Longs Exit",
                    "time":now_str,"oi_change":p5})
            if price_up and c5<-threshold:
                new_acts.append({"type":"SHORT_COVER","strike":d["strike"],
                    "label":"Short Covering","detail":f"Call OI {sfmt(c5)} | Shorts Cover",
                    "time":now_str,"oi_change":c5})

        # Method 2: Day OI % fallback
        if pchg>15 and poi>300000:
            new_acts.append({"type":"LONG_BUILDUP","strike":d["strike"],
                "label":"Long Buildup","detail":f"Put OI Day +{pchg:.1f}% | {sfmt(poi)}",
                "time":now_str,"oi_change":poi*pchg/100})
        if cchg>15 and coi>300000:
            new_acts.append({"type":"SHORT_BUILDUP","strike":d["strike"],
                "label":"Short Buildup","detail":f"Call OI Day +{cchg:.1f}% | {sfmt(coi)}",
                "time":now_str,"oi_change":coi*cchg/100})
        if pchg<-10 and poi>200000:
            new_acts.append({"type":"LONG_UNWIND","strike":d["strike"],
                "label":"Long Unwinding","detail":f"Put OI Day {pchg:.1f}% | {sfmt(poi)}",
                "time":now_str,"oi_change":abs(poi*pchg/100)})
        if cchg<-10 and coi>200000:
            new_acts.append({"type":"SHORT_COVER","strike":d["strike"],
                "label":"Short Covering","detail":f"Call OI Day {cchg:.1f}% | {sfmt(coi)}",
                "time":now_str,"oi_change":abs(coi*cchg/100)})

        activities.extend(new_acts)

        # Add new activities to timestamped log
        for act in new_acts:
            existing = [a for a in activity_log[symbol]
                        if a["strike"]==act["strike"] and a["type"]==act["type"]
                        and a["time"]==now_str]
            if not existing:
                activity_log[symbol].appendleft({**act, "spot_at_time": round(spot,2)})

    # Deduplicate
    seen,unique = set(),[]
    for a in activities:
        k = f"{a['type']}_{a['strike']}"
        if k not in seen:
            seen.add(k)
            unique.append(a)

    unique.sort(key=lambda x:x.get("oi_change",0), reverse=True)
    return unique[:15]

# ════════════════════════════════════════
#  MAX PAIN + SIGNAL
# ════════════════════════════════════════
def calc_max_pain(chain):
    if not chain: return 0
    best,mp = float("inf"),chain[0]["strike"]
    for s in chain:
        loss = sum(d["callOI"]*max(0,s["strike"]-d["strike"])+
                   d["putOI"]*max(0,d["strike"]-s["strike"]) for d in chain)
        if loss<best: best,mp = loss,s["strike"]
    return mp

def gen_signal(pcr,spot,cwall,pwall,chg):
    if not cwall or not pwall: return "WAIT","Insufficient OI data"
    cd,pd = cwall-spot,spot-pwall
    if pcr>1.2 and chg>0 and pd<cd: return "BUY",f"PCR {pcr:.2f} Bullish | Put Wall {pwall:,.0f} holding"
    if pcr<0.8 and chg<0:           return "SELL",f"PCR {pcr:.2f} Bearish | Call Wall {cwall:,.0f} resisting"
    if cd<150:                       return "WAIT",f"Near Call Wall {cwall:,.0f} — resistance zone"
    if pd<150:                       return "WAIT",f"Near Put Wall {pwall:,.0f} — support test"
    if 0.8<=pcr<=1.2:                return "WAIT",f"PCR {pcr:.2f} neutral — wait for breakout"
    return "BUY",f"Put writers active | PCR {pcr:.2f}"

def sfmt(n):
    n=n or 0; a=abs(n)
    if a>=1e7: return f"{n/1e7:.1f}Cr"
    if a>=1e5: return f"{n/1e5:.1f}L"
    if a>=1e3: return f"{n/1e3:.0f}K"
    return str(int(n))

# ════════════════════════════════════════
#  AUTH
# ════════════════════════════════════════
def load_token():
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE) as f:
            t=f.read().strip()
            if t:
                kite.set_access_token(t)
                return True
    return False

@app.route("/")
def index():
    if load_token():
        return send_from_directory("static","dashboard.html")
    url = kite.login_url()
    return f"""<html><head><style>
    body{{background:#020d1a;color:#c8e0f0;font-family:'Courier New',mono;
    display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;margin:0;}}
    h2{{color:#00d4ff;letter-spacing:0.1em;}}p{{color:#4a7a9b;font-size:0.85rem;margin:0.3rem 0;}}
    .sub{{color:#ffd700;margin-top:1rem;}}
    a{{display:inline-block;margin-top:2rem;padding:1rem 2.5rem;background:#00d4ff;
    color:#020d1a;font-weight:700;letter-spacing:0.15em;text-decoration:none;}}
    a:hover{{background:#00ff88;}}
    .badge{{display:flex;gap:0.8rem;margin-top:1.5rem;flex-wrap:wrap;justify-content:center;}}
    .b{{border:1px solid #00d4ff;padding:0.3rem 0.8rem;font-size:0.65rem;color:#00d4ff;}}
    </style></head><body>
    <h2>⬡ OI TERMINAL v3.0</h2><p>Nifty + BankNifty · Paper Trading Edition</p>
    <div class="badge">
      <div class="b">OI ACTIVITY + TIMESTAMPS</div>
      <div class="b">5 STRATEGIES</div>
      <div class="b">PAPER TRADING</div>
      <div class="b">AUTO EXECUTION</div>
      <div class="b">P&L TRACKING</div>
    </div>
    <p class="sub">Login with your Zerodha account</p>
    <a href="{url}">Login with Zerodha</a></body></html>"""

@app.route("/callback")
def callback():
    rt = request.args.get("request_token")
    if not rt: return "No token. <a href='/'>Try Again</a>",400
    try:
        d = kite.generate_session(rt,api_secret=API_SECRET)
        kite.set_access_token(d["access_token"])
        with open(TOKEN_FILE,"w") as f: f.write(d["access_token"])
        threading.Thread(target=get_instruments,daemon=True).start()
        return redirect("/")
    except Exception as e:
        return f"Login failed: {e} <a href='/'>Try Again</a>",400

# ════════════════════════════════════════
#  MAIN OI API
# ════════════════════════════════════════
@app.route("/api/data/<symbol>")
def api_data(symbol):
    symbol = symbol.upper()
    if symbol not in ("NIFTY","BANKNIFTY"):
        return jsonify({"error":"Invalid"}),400

    now = time.time()
    if now-last_updated[symbol]<10 and oi_cache[symbol]:
        return jsonify(oi_cache[symbol])

    try:
        t0         = time.time()
        chain_data = get_chain_fast(symbol)
        chain      = chain_data.get("chain",[])
        expiry     = chain_data.get("expiry","N/A")
        spot_data  = chain_data.get("spot",{})
        spot       = spot_data.get("last_price",0)
        chg        = spot_data.get("change",0)

        prev_spot  = price_history[symbol][-1] if price_history[symbol] else spot
        price_history[symbol].append(spot)

        total_call = sum(d["callOI"] for d in chain)
        total_put  = sum(d["putOI"]  for d in chain)
        pcr        = round(total_put/max(total_call,1),2)

        pcr_history[symbol].append({"time":datetime.now().strftime("%H:%M"),"pcr":pcr})

        cwall = max(chain,key=lambda x:x["callOI"],default={}).get("strike",0) if chain else 0
        pwall = max(chain,key=lambda x:x["putOI"], default={}).get("strike",0) if chain else 0

        signal,reason  = gen_signal(pcr,spot,cwall,pwall,chg)
        activities     = detect_activity(symbol,chain,spot,prev_spot)

        # Check strategy signals + auto paper trade
        strat_signals  = check_strategy_signals(symbol,pcr,spot,cwall,pwall,activities,chg)
        for sig in strat_signals:
            auto_execute_paper_trade(symbol,sig,spot)

        # Check exits
        check_exit_paper_trades(symbol,spot)

        fm = {
            "long_buildup":  sum(1 for a in activities if a["type"]=="LONG_BUILDUP"),
            "short_buildup": sum(1 for a in activities if a["type"]=="SHORT_BUILDUP"),
            "long_unwind":   sum(1 for a in activities if a["type"]=="LONG_UNWIND"),
            "short_cover":   sum(1 for a in activities if a["type"]=="SHORT_COVER"),
        }

        elapsed = round(time.time()-t0,2)
        print(f"[{datetime.now():%H:%M:%S}] {symbol} {elapsed}s | PCR={pcr} | {signal} | Strat:{len(strat_signals)}")

        result = {
            "status":"ok","symbol":symbol,
            "spot":spot_data,"chain":chain,"expiry":expiry,"pcr":pcr,
            "pcr_history":list(pcr_history[symbol]),
            "call_wall":cwall,"put_wall":pwall,
            "max_pain":calc_max_pain(chain),
            "total_call_oi":total_call,"total_put_oi":total_put,
            "signal":signal,"signal_reason":reason,
            "activities":activities,"five_min_summary":fm,
            "strategy_signals":strat_signals,
            "activity_log":list(activity_log[symbol])[:30],
            "fetch_time":elapsed,
            "timestamp":datetime.now().strftime("%H:%M:%S"),
        }
        oi_cache[symbol]     = result
        last_updated[symbol] = now
        return jsonify(result)

    except Exception as e:
        print(f"API error {symbol}: {e}")
        return jsonify({"status":"error","message":str(e)}),500

# ════════════════════════════════════════
#  PAPER TRADING APIs
# ════════════════════════════════════════
@app.route("/api/paper/state")
def api_paper_state():
    with paper_lock:
        return jsonify(paper_state)

@app.route("/api/paper/reset", methods=["POST"])
def api_paper_reset():
    global paper_state
    with paper_lock:
        paper_state = {
            "capital":100000,"available":100000,"total_pnl":0,
            "trades":[],"open_positions":[],"daily_pnl":{},
            "stats":{"total_trades":0,"wins":0,"losses":0,"max_win":0,"max_loss":0}
        }
        save_paper_state(paper_state)
    return jsonify({"status":"reset"})

@app.route("/api/paper/close/<position_id>", methods=["POST"])
def api_paper_close(position_id):
    """Manually close a paper position."""
    data  = request.json or {}
    spot  = data.get("spot",0)
    with paper_lock:
        state   = paper_state
        now_str = datetime.now().strftime("%H:%M:%S")
        found   = None
        remaining = []
        for pos in state["open_positions"]:
            if pos["id"] == position_id:
                found = pos
            else:
                remaining.append(pos)
        if not found:
            return jsonify({"error":"Not found"}),404

        if pos["direction"]=="BUY":
            pnl = round((spot-pos["entry"])*pos["qty"],2)
        else:
            pnl = round((pos["entry"]-spot)*pos["qty"],2)

        trade = {**found,"exit":spot,"exit_time":now_str,
                 "exit_reason":"MANUAL","pnl":pnl,
                 "result":"WIN" if pnl>0 else "LOSS","status":"CLOSED"}
        state["trades"].append(trade)
        state["total_pnl"]   = round(state["total_pnl"]+pnl,2)
        state["available"]   = round(state["available"]+pnl,2)
        state["open_positions"] = remaining
        state["stats"]["total_trades"] += 1
        if pnl>0: state["stats"]["wins"]+=1
        else:     state["stats"]["losses"]+=1
        today = str(date.today())
        state["daily_pnl"][today] = round(state["daily_pnl"].get(today,0)+pnl,2)
        save_paper_state(state)
    return jsonify({"status":"closed","pnl":pnl})

@app.route("/api/paper/strategies")
def api_strategies():
    return jsonify(STRATEGIES)

@app.route("/api/activity_log/<symbol>")
def api_activity_log(symbol):
    symbol = symbol.upper()
    return jsonify(list(activity_log.get(symbol,[])))

@app.route("/api/health")
def health():
    return jsonify({"status":"running","logged_in":os.path.exists(TOKEN_FILE),
                    "instruments":len(_instruments_cache)})

if __name__ == "__main__":
    print("\n"+"="*60)
    print("  ⬡ OI TERMINAL v3.0 — PAPER TRADING EDITION")
    print("  Nifty 50 + Bank Nifty")
    print("="*60)
    print("  → Open: http://127.0.0.1:5000")
    print("  → Paper Trading: Virtual ₹1,00,000 capital")
    print("  → 5 Auto Strategies ready")
    print("  → OI Activity with full timestamps")
    print("="*60+"\n")
    if load_token():
        threading.Thread(target=get_instruments,daemon=True).start()
    app.run(debug=False,port=5000,threaded=True)
