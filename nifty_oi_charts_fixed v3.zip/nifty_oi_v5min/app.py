"""
OI Terminal v5.0 — EMA 5-Min Candle Strategy Edition
=====================================================
NEW FEATURES v5.0:
- EMA strategy purely based on 5-min CANDLE CLOSE (not tick)
- Dual confirmation: Index candle + ATM premium candle both close above/below 9 EMA
- Time filter: entries only 9:45 AM – 3:00 PM
- Auto square-off all positions at 3:30 PM
- Premium gap filter: ATM premium gap from EMA ≤ 5%
- Target: +20 pts premium | SL: -10 pts premium | Trail: 5 pts
- Lots: 10 | Strategy engine START / STOP control
"""

from flask import Flask, redirect, request, jsonify, send_from_directory
from kiteconnect import KiteConnect
import os, time, threading, json
from datetime import datetime, date
from collections import deque

app = Flask(__name__, static_folder='static')

# ── CREDENTIALS ──
API_KEY    = "YOUR_API_KEY_HERE"
API_SECRET = "YOUR_API_SECRET_HERE"
kite       = KiteConnect(api_key=API_KEY)
TOKEN_FILE = "access_token.txt"

# ── INSTRUMENT CACHE ──
_instruments_cache = []
_instruments_date  = None
_instruments_lock  = threading.Lock()
_sym_map           = {}
_sym_map_lock      = threading.Lock()

# ── CONFIG ──
SPOT_KEYS  = {"NIFTY": "NSE:NIFTY 50", "BANKNIFTY": "NSE:NIFTY BANK"}
STEP       = {"NIFTY": 50, "BANKNIFTY": 100}
STRIKES_N  = 15
SNAPSHOT_INTERVAL = 300  # 5 minute OI snapshots

# ── OI STATE ──
pcr_history   = {"NIFTY": deque(maxlen=30), "BANKNIFTY": deque(maxlen=30)}
price_history = {"NIFTY": deque(maxlen=6),  "BANKNIFTY": deque(maxlen=6)}
oi_cache      = {"NIFTY": {}, "BANKNIFTY": {}}
last_updated  = {"NIFTY": 0,  "BANKNIFTY": 0}
last_snapshot = {"NIFTY": {}, "BANKNIFTY": {}}
last_snap_time= {"NIFTY": 0,  "BANKNIFTY": 0}

# ── ACTIVITY LOG ──
activity_log = {"NIFTY": deque(maxlen=100), "BANKNIFTY": deque(maxlen=100)}

# ════════════════════════════════════════
#  STRATEGY ENGINE START/STOP CONTROL
# ════════════════════════════════════════
strategy_engine_running = False
strategy_engine_lock    = threading.Lock()

def is_strategy_running():
    with strategy_engine_lock:
        return strategy_engine_running

# ════════════════════════════════════════
#  5-MIN CANDLE AGGREGATOR
# ════════════════════════════════════════
# Each symbol stores the current forming 5-min candle and completed candles.
# A "candle" has: open, high, low, close (for index), and same for atm_call / atm_put.
# We use wall-clock 5-min bars: 9:15-9:20, 9:20-9:25 ... etc.

five_min_candles = {
    "NIFTY":     {"current_bar": None, "completed": deque(maxlen=200)},
    "BANKNIFTY": {"current_bar": None, "completed": deque(maxlen=200)},
}
five_min_lock = threading.Lock()

# ── Historical data already loaded flag ──
hist_loaded = {"NIFTY": False, "BANKNIFTY": False}

# Kite instrument tokens for index (fixed, doesn't change)
INDEX_TOKENS = {
    "NIFTY":     256265,   # NSE:NIFTY 50
    "BANKNIFTY": 260105,   # NSE:NIFTY BANK
}

# ════════════════════════════════════════
#  HISTORICAL CANDLE LOADER
# ════════════════════════════════════════
def load_historical_candles(symbol):
    """
    Fetch today's (and yesterday's if today has < 10 candles) 5-min
    OHLC from Kite historical API and pre-fill the candle store + EMA.
    Also fetches ATM Call/Put premium history for the same period.
    """
    global hist_loaded
    if hist_loaded.get(symbol):
        return
    try:
        from datetime import timedelta
        today     = date.today()
        # Fetch last 2 trading days to ensure enough candles
        from_date = today - timedelta(days=5)   # go back 5 calendar days (covers weekends)
        to_date   = today

        token = INDEX_TOKENS[symbol]
        print(f"[HIST] Loading {symbol} 5-min candles from {from_date} to {to_date}...")

        # Fetch index historical candles
        idx_hist = kite.historical_data(
            instrument_token = token,
            from_date        = from_date,
            to_date          = to_date,
            interval         = "5minute",
            continuous       = False,
            oi               = False,
        )
        if not idx_hist:
            print(f"[HIST] No data returned for {symbol}")
            return

        # Get current ATM strike for this symbol
        step = STEP[symbol]
        # Use last close from historical to estimate ATM
        last_idx_close = idx_hist[-1]["close"] if idx_hist else 0
        atm = round(last_idx_close / step) * step

        # Get nearest expiry for ATM options
        expiry = get_nearest_expiry(symbol)
        if not expiry:
            print(f"[HIST] No expiry found for {symbol}, loading index only")
            expiry = None

        # Fetch ATM Call + Put historical data
        call_hist_map = {}
        put_hist_map  = {}

        if expiry:
            with _sym_map_lock:
                strike_map = _sym_map.get(f"{symbol}|{expiry}", {})

            # Try ATM and ±1 strike to find best token
            for strike_offset in [0, step, -step]:
                test_strike = atm + strike_offset
                sm = strike_map.get(test_strike, {})
                call_tsym = sm.get("CE")
                put_tsym  = sm.get("PE")

                if call_tsym and put_tsym:
                    # Find instrument tokens
                    call_token = None
                    put_token  = None
                    with _instruments_lock:
                        for inst in _instruments_cache:
                            if inst["tradingsymbol"] == call_tsym:
                                call_token = inst["instrument_token"]
                            if inst["tradingsymbol"] == put_tsym:
                                put_token = inst["instrument_token"]

                    if call_token:
                        try:
                            ch = kite.historical_data(
                                instrument_token = call_token,
                                from_date        = from_date,
                                to_date          = to_date,
                                interval         = "5minute",
                            )
                            for bar in ch:
                                k = bar["date"].strftime("%H:%M") if hasattr(bar["date"],"strftime") else str(bar["date"])[11:16]
                                call_hist_map[k] = bar["close"]
                        except Exception as e:
                            print(f"[HIST] Call history error: {e}")

                    if put_token:
                        try:
                            ph = kite.historical_data(
                                instrument_token = put_token,
                                from_date        = from_date,
                                to_date          = to_date,
                                interval         = "5minute",
                            )
                            for bar in ph:
                                k = bar["date"].strftime("%H:%M") if hasattr(bar["date"],"strftime") else str(bar["date"])[11:16]
                                put_hist_map[k] = bar["close"]
                        except Exception as e:
                            print(f"[HIST] Put history error: {e}")

                    if call_hist_map or put_hist_map:
                        print(f"[HIST] {symbol} ATM {test_strike} CE/PE history loaded")
                        break

        # ── Fill the candle store from historical data ──
        # Group by date: use only today's candles OR last trading day if market closed
        from collections import defaultdict
        by_date = defaultdict(list)
        for bar in idx_hist:
            d = bar["date"]
            day_str = d.strftime("%Y-%m-%d") if hasattr(d,"strftime") else str(d)[:10]
            by_date[day_str].append(bar)

        # Pick last available day with data (today if market open, else last trading day)
        sorted_days = sorted(by_date.keys())
        if not sorted_days:
            return

        # Use last 2 days of data for enough EMA warmup
        days_to_use = sorted_days[-2:] if len(sorted_days) >= 2 else sorted_days

        loaded_count = 0
        with five_min_lock:
            fd = five_min_candles[symbol]
            fd["completed"].clear()

            for day_str in days_to_use:
                bars = by_date[day_str]
                for bar in bars:
                    d      = bar["date"]
                    bk     = d.strftime("%H:%M") if hasattr(d,"strftime") else str(d)[11:16]
                    # Only market hours 9:15 to 15:30
                    hr, mn = int(bk[:2]), int(bk[3:5])
                    if not (9*60+15 <= hr*60+mn <= 15*60+25):
                        continue

                    call_ltp = call_hist_map.get(bk, 0)
                    put_ltp  = put_hist_map.get(bk, 0)

                    # If no option data for this bar, interpolate / use 0
                    candle = {
                        "bar_key":    bk,
                        "bar_date":   day_str,
                        "idx_open":   bar["open"],
                        "idx_high":   bar["high"],
                        "idx_low":    bar["low"],
                        "idx_close":  bar["close"],
                        "call_open":  call_ltp,
                        "call_high":  call_ltp,
                        "call_low":   call_ltp,
                        "call_close": call_ltp,
                        "put_open":   put_ltp,
                        "put_high":   put_ltp,
                        "put_low":    put_ltp,
                        "put_close":  put_ltp,
                    }
                    fd["completed"].append(candle)
                    loaded_count += 1

                    # Feed into EMA
                    update_ema_on_candle_close(symbol, candle)

        hist_loaded[symbol] = True
        print(f"[HIST] {symbol}: loaded {loaded_count} historical 5-min candles ✓")

    except Exception as e:
        print(f"[HIST] Error loading {symbol} history: {e}")

def load_all_historical(delay=3):
    """Load historical candles for both symbols after a short delay (let instruments load first)."""
    time.sleep(delay)
    get_instruments()   # ensure instruments are loaded
    for sym in ["NIFTY", "BANKNIFTY"]:
        load_historical_candles(sym)

def get_5min_bar_key(dt):
    """Return the 5-min bar start time string for a given datetime."""
    minute_slot = (dt.minute // 5) * 5
    return dt.replace(minute=minute_slot, second=0, microsecond=0)

def update_5min_candle(symbol, index_price, atm_call_ltp, atm_put_ltp):
    """
    Feed a new tick into the 5-min candle aggregator.
    Returns the just-completed candle if a new bar started, else None.
    """
    now      = datetime.now()
    bar_time = get_5min_bar_key(now)
    bar_key  = bar_time.strftime("%H:%M")
    completed_candle = None

    with five_min_lock:
        fd = five_min_candles[symbol]
        cur = fd["current_bar"]

        if cur is None or cur["bar_key"] != bar_key:
            # New 5-min bar started — save the old one as completed
            if cur is not None:
                completed_candle = dict(cur)
                fd["completed"].append(completed_candle)
            # Open new bar
            fd["current_bar"] = {
                "bar_key":       bar_key,
                "bar_time":      bar_time,
                # Index candle
                "idx_open":      index_price,
                "idx_high":      index_price,
                "idx_low":       index_price,
                "idx_close":     index_price,
                # ATM Call premium candle
                "call_open":     atm_call_ltp,
                "call_high":     atm_call_ltp,
                "call_low":      atm_call_ltp,
                "call_close":    atm_call_ltp,
                # ATM Put premium candle
                "put_open":      atm_put_ltp,
                "put_high":      atm_put_ltp,
                "put_low":       atm_put_ltp,
                "put_close":     atm_put_ltp,
            }
        else:
            # Update current bar
            cur["idx_high"]   = max(cur["idx_high"],   index_price)
            cur["idx_low"]    = min(cur["idx_low"],    index_price)
            cur["idx_close"]  = index_price
            cur["call_high"]  = max(cur["call_high"],  atm_call_ltp)
            cur["call_low"]   = min(cur["call_low"],   atm_call_ltp)
            cur["call_close"] = atm_call_ltp
            cur["put_high"]   = max(cur["put_high"],   atm_put_ltp)
            cur["put_low"]    = min(cur["put_low"],    atm_put_ltp)
            cur["put_close"]  = atm_put_ltp

    return completed_candle  # None if no bar closed, else the closed bar dict

# ════════════════════════════════════════
#  EMA ENGINE (on 5-min candle closes)
# ════════════════════════════════════════
ema_data = {
    "NIFTY": {
        "index_closes":   deque(maxlen=100),  # Close of each completed 5-min candle
        "call_closes":    deque(maxlen=100),
        "put_closes":     deque(maxlen=100),
        "timestamps":     deque(maxlen=100),
        "ema9_index":     deque(maxlen=100),
        "ema9_call":      deque(maxlen=100),
        "ema9_put":       deque(maxlen=100),
        # Keep last tick prices for display
        "last_index":     0,
        "last_call":      0,
        "last_put":       0,
    },
    "BANKNIFTY": {
        "index_closes":   deque(maxlen=100),
        "call_closes":    deque(maxlen=100),
        "put_closes":     deque(maxlen=100),
        "timestamps":     deque(maxlen=100),
        "ema9_index":     deque(maxlen=100),
        "ema9_call":      deque(maxlen=100),
        "ema9_put":       deque(maxlen=100),
        "last_index":     0,
        "last_call":      0,
        "last_put":       0,
    }
}

def calc_ema(prices, period):
    prices_list = list(prices)
    if not prices_list:
        return []
    ema = [prices_list[0]]
    k = 2.0 / (period + 1)
    for p in prices_list[1:]:
        ema.append(p * k + ema[-1] * (1 - k))
    return ema

def update_ema_on_candle_close(symbol, candle):
    """Called when a 5-min candle completes. Updates EMA series."""
    ed = ema_data[symbol]
    ed["index_closes"].append(candle["idx_close"])
    ed["call_closes"].append(candle["call_close"])
    ed["put_closes"].append(candle["put_close"])
    ed["timestamps"].append(candle["bar_key"])
    ed["ema9_index"] = deque(calc_ema(ed["index_closes"], 9), maxlen=100)
    ed["ema9_call"]  = deque(calc_ema(ed["call_closes"],  9), maxlen=100)
    ed["ema9_put"]   = deque(calc_ema(ed["put_closes"],   9), maxlen=100)

def update_last_tick(symbol, spot, call_ltp, put_ltp):
    """Store latest tick values for display even between candle closes."""
    ed = ema_data[symbol]
    ed["last_index"] = spot
    ed["last_call"]  = call_ltp
    ed["last_put"]   = put_ltp

def is_in_trade_window():
    """Returns True if current time is between 9:45 AM and 3:00 PM."""
    now = datetime.now()
    start = now.replace(hour=9,  minute=45, second=0, microsecond=0)
    end   = now.replace(hour=15, minute=0,  second=0, microsecond=0)
    return start <= now <= end

def is_squareoff_time():
    """Returns True if it is 3:30 PM or later (auto square-off)."""
    now = datetime.now()
    sq  = now.replace(hour=15, minute=30, second=0, microsecond=0)
    return now >= sq

def check_ema_5min_signal(symbol, candle):
    """
    Check strategy conditions on just-closed 5-min candle.
    Returns signal dict or None.

    BUY CALL:
      - Index candle closes ABOVE 9 EMA (crossover: prev close was below)
      - ATM Call candle closes ABOVE its 9 EMA (crossover)
      - ATM Call premium gap from EMA ≤ 5%

    BUY PUT:
      - Index candle closes BELOW 9 EMA (crossover: prev close was above)
      - ATM Put candle closes ABOVE its 9 EMA (crossover)
      - ATM Put premium gap from EMA ≤ 5%
    """
    ed = ema_data[symbol]

    idx_closes  = list(ed["index_closes"])
    call_closes = list(ed["call_closes"])
    put_closes  = list(ed["put_closes"])
    ema9_idx    = list(ed["ema9_index"])
    ema9_call   = list(ed["ema9_call"])
    ema9_put    = list(ed["ema9_put"])

    # Need at least 2 closed candles for crossover detection
    if len(idx_closes) < 2 or len(ema9_idx) < 2:
        return None

    # Current and previous closes
    idx_cur, idx_prev        = idx_closes[-1],  idx_closes[-2]
    call_cur, call_prev      = call_closes[-1], call_closes[-2]
    put_cur, put_prev        = put_closes[-1],  put_closes[-2]
    ema9_idx_cur             = ema9_idx[-1]
    ema9_idx_prev            = ema9_idx[-2]     if len(ema9_idx) >= 2 else ema9_idx[-1]
    ema9_call_cur            = ema9_call[-1]    if ema9_call else 0
    ema9_call_prev           = ema9_call[-2]    if len(ema9_call) >= 2 else ema9_call_cur
    ema9_put_cur             = ema9_put[-1]     if ema9_put else 0
    ema9_put_prev            = ema9_put[-2]     if len(ema9_put) >= 2 else ema9_put_cur

    now_str = datetime.now().strftime("%H:%M:%S")

    # ── BUY CALL CONDITIONS ──
    idx_cross_up   = (idx_cur  > ema9_idx_cur)  and (idx_prev  <= ema9_idx_prev)
    call_cross_up  = (call_cur > ema9_call_cur) and (call_prev <= ema9_call_prev)
    call_gap_pct   = abs(call_cur - ema9_call_cur) / max(ema9_call_cur, 1) * 100

    if idx_cross_up and call_cross_up and call_gap_pct <= 5:
        return {
            "type":           "BUY_CALL",
            "direction":      "BUY",
            "option":         "CALL",
            "entry_premium":  call_cur,
            "target":         round(call_cur + 20, 2),
            "sl":             round(call_cur - 10, 2),
            "trailing_pts":   5,
            "qty":            10,
            "ema9_index":     round(ema9_idx_cur, 2),
            "ema9_call":      round(ema9_call_cur, 2),
            "call_gap_pct":   round(call_gap_pct, 2),
            "reason":         f"Index crossed above 9EMA + ATM Call crossed above 9EMA | Gap:{call_gap_pct:.1f}%",
            "time":           now_str,
            "bar":            candle["bar_key"],
        }

    # ── BUY PUT CONDITIONS ──
    idx_cross_down = (idx_cur  < ema9_idx_cur)  and (idx_prev  >= ema9_idx_prev)
    put_cross_up   = (put_cur  > ema9_put_cur)  and (put_prev  <= ema9_put_prev)
    put_gap_pct    = abs(put_cur - ema9_put_cur) / max(ema9_put_cur, 1) * 100

    if idx_cross_down and put_cross_up and put_gap_pct <= 5:
        return {
            "type":           "BUY_PUT",
            "direction":      "BUY",
            "option":         "PUT",
            "entry_premium":  put_cur,
            "target":         round(put_cur + 20, 2),
            "sl":             round(put_cur - 10, 2),
            "trailing_pts":   5,
            "qty":            10,
            "ema9_index":     round(ema9_idx_cur, 2),
            "ema9_put":       round(ema9_put_cur, 2),
            "put_gap_pct":    round(put_gap_pct, 2),
            "reason":         f"Index crossed below 9EMA + ATM Put crossed above 9EMA | Gap:{put_gap_pct:.1f}%",
            "time":           now_str,
            "bar":            candle["bar_key"],
        }

    return None

def get_ema_display_data(symbol):
    """Return EMA chart data for the frontend (using candle closes)."""
    ed = ema_data[symbol]
    return {
        "timestamps":   list(ed["timestamps"]),
        "index_prices": list(ed["index_closes"]),
        "ema9_index":   list(ed["ema9_index"]),
        "ema21_index":  [],   # Not used in new strategy, kept for compat
        "atm_call_ltp": list(ed["call_closes"]),
        "ema9_call":    list(ed["ema9_call"]),
        "ema21_call":   [],
        "atm_put_ltp":  list(ed["put_closes"]),
        "ema9_put":     list(ed["ema9_put"]),
        "ema21_put":    [],
        "current_signals": {},
        "last_index":   ed["last_index"],
        "last_call":    ed["last_call"],
        "last_put":     ed["last_put"],
        "candle_count": len(ed["index_closes"]),
    }

# ════════════════════════════════════════
#  EMA PAPER TRADING ENGINE
# ════════════════════════════════════════
EMA_PAPER_FILE = "ema_paper_trades.json"

def load_ema_paper_state():
    if os.path.exists(EMA_PAPER_FILE):
        try:
            with open(EMA_PAPER_FILE) as f:
                return json.load(f)
        except:
            pass
    return {
        "capital": 100000, "available": 100000, "total_pnl": 0,
        "trades": [], "open_positions": [], "daily_pnl": {},
        "stats": {"total_trades": 0, "wins": 0, "losses": 0, "max_win": 0, "max_loss": 0},
        "engine_running": False,
    }

def save_ema_paper_state(state):
    with open(EMA_PAPER_FILE, "w") as f:
        json.dump(state, f, indent=2)

ema_paper_state = load_ema_paper_state()
ema_paper_lock  = threading.Lock()

def auto_execute_ema_trade(symbol, signal):
    """Open a new EMA trade based on the 5-min candle signal."""
    global ema_paper_state
    if not is_strategy_running():
        return None
    if not is_in_trade_window():
        print(f"[EMA] Signal ignored — outside trade window ({datetime.now().strftime('%H:%M')})")
        return None

    with ema_paper_lock:
        state  = ema_paper_state
        option = signal["option"]  # "CALL" or "PUT"

        # Only one position per symbol+option type at a time
        existing = [p for p in state["open_positions"]
                    if p["symbol"] == symbol and p.get("option") == option]
        if existing:
            return None

        entry_premium = signal["entry_premium"]
        target        = signal["target"]
        sl            = signal["sl"]
        trailing_pts  = signal["trailing_pts"]
        qty           = signal["qty"]

        position = {
            "id":              f"EMA{int(time.time()*1000)}",
            "symbol":          symbol,
            "option":          option,
            "strategy":        "EMA_9_21_5MIN",
            "direction":       "BUY",
            "entry":           entry_premium,
            "target":          target,
            "sl":              sl,
            "initial_sl":      sl,
            "trailing_pts":    trailing_pts,
            "qty":             qty,
            "entry_time":      signal["time"],
            "bar":             signal.get("bar", ""),
            "reason":          signal["reason"],
            "pnl":             0,
            "status":          "OPEN",
            "highest_premium": entry_premium,   # For trailing SL (BUY option)
        }
        state["open_positions"].append(position)
        save_ema_paper_state(state)
        print(f"[EMA 5MIN] BUY {option} {symbol} @ premium {entry_premium} | TGT:{target} SL:{sl} | {signal['reason']}")
        return position

def check_exit_ema_trades(symbol, atm_call_ltp, atm_put_ltp, force_squareoff=False):
    """
    Check exits for open EMA positions.
    - Trailing SL: every 5 pts rise in premium → SL trails up 5 pts
    - Target: +20 pts from entry premium
    - SL: -10 pts from entry premium (trails up every 5 pts)
    - P&L: (current_premium - entry_premium) * qty
    - Force squareoff at 3:30 PM using current premium
    """
    global ema_paper_state
    exited = []
    with ema_paper_lock:
        state   = ema_paper_state
        now_str = datetime.now().strftime("%H:%M:%S")
        remaining = []
        for pos in state["open_positions"]:
            if pos["symbol"] != symbol or pos.get("strategy") != "EMA_9_21_5MIN":
                remaining.append(pos); continue

            # Get current premium for this position's option type
            option  = pos.get("option", "CALL")
            cur_ltp = atm_call_ltp if option == "CALL" else atm_put_ltp

            # Update unrealized P&L
            pos["pnl"] = round((cur_ltp - pos["entry"]) * pos["qty"], 2)

            # ── TRAILING SL UPDATE ──
            # Every 5 pt rise from entry → SL trails up by 5 pts
            # Track highest premium reached
            if cur_ltp > pos.get("highest_premium", pos["entry"]):
                pos["highest_premium"] = cur_ltp
                # How many 5-pt tiers have we climbed above entry?
                tiers  = int((cur_ltp - pos["entry"]) / pos["trailing_pts"])
                new_sl = round(pos["initial_sl"] + tiers * pos["trailing_pts"], 2)
                if new_sl > pos["sl"]:
                    pos["sl"] = new_sl

            # ── EXIT CONDITIONS ──
            hit_target   = cur_ltp >= pos["target"]
            hit_sl       = cur_ltp <= pos["sl"]
            hit_squareoff = force_squareoff or is_squareoff_time()

            if hit_target or hit_sl or hit_squareoff:
                exit_price  = cur_ltp  # Exit at current premium
                exit_reason = "TARGET" if hit_target else ("TRAILING SL" if hit_sl else "3:30 SQUAREOFF")
                pnl         = round((exit_price - pos["entry"]) * pos["qty"], 2)
                result      = "WIN" if pnl >= 0 else "LOSS"
                trade = {**pos, "exit": exit_price, "exit_time": now_str,
                         "exit_reason": exit_reason,
                         "pnl": pnl, "result": result, "status": "CLOSED"}
                state["trades"].append(trade)
                state["total_pnl"]  = round(state["total_pnl"] + pnl, 2)
                state["available"]  = round(state["available"] + pnl, 2)
                state["stats"]["total_trades"] += 1
                if pnl >= 0:
                    state["stats"]["wins"]   += 1
                    state["stats"]["max_win"] = max(state["stats"].get("max_win",0), pnl)
                else:
                    state["stats"]["losses"] += 1
                    state["stats"]["max_loss"] = min(state["stats"].get("max_loss",0), pnl)
                today = str(date.today())
                state["daily_pnl"][today] = round(state["daily_pnl"].get(today,0)+pnl,2)
                exited.append(trade)
                print(f"[EMA 5MIN] CLOSED BUY {option} {symbol} Entry:{pos['entry']} "
                      f"Exit:{exit_price} P&L:₹{pnl} {result} ({exit_reason})")
            else:
                remaining.append(pos)
        state["open_positions"] = remaining
        if exited: save_ema_paper_state(state)
    return exited

def squareoff_all_ema_positions(symbol):
    """Force close all open EMA positions for a symbol at 3:30 PM."""
    ed = ema_data[symbol]
    call_ltp = ed.get("last_call", 0) or 0
    put_ltp  = ed.get("last_put",  0) or 0
    return check_exit_ema_trades(symbol, call_ltp, put_ltp, force_squareoff=True)

# ════════════════════════════════════════
#  OI PAPER TRADING ENGINE
# ════════════════════════════════════════
PAPER_FILE = "paper_trades.json"

def load_paper_state():
    if os.path.exists(PAPER_FILE):
        try:
            with open(PAPER_FILE) as f:
                return json.load(f)
        except:
            pass
    return {
        "capital": 100000, "available": 100000, "total_pnl": 0,
        "trades": [], "open_positions": [], "daily_pnl": {},
        "stats": {"total_trades": 0, "wins": 0, "losses": 0, "max_win": 0, "max_loss": 0}
    }

def save_paper_state(state):
    with open(PAPER_FILE, "w") as f:
        json.dump(state, f, indent=2)

paper_state = load_paper_state()
paper_lock  = threading.Lock()

STRATEGIES = {
    "PCR_REVERSAL":       {"name": "PCR Reversal",       "description": "Buy PCR>1.3, Sell PCR<0.7.", "risk": "Low",    "target_pts": 80,  "sl_pts": 40, "rr": "1:2"},
    "CALL_WALL_BREAKOUT": {"name": "Call Wall Breakout", "description": "Buy when price attacks Call Wall.", "risk": "Medium", "target_pts": 120, "sl_pts": 60, "rr": "1:2"},
    "PUT_WALL_BOUNCE":    {"name": "Put Wall Bounce",    "description": "Buy at Put Wall support.", "risk": "Low",    "target_pts": 80,  "sl_pts": 40, "rr": "1:2"},
    "LONG_BUILDUP_RIDE":  {"name": "Long Buildup Ride",  "description": "Enter when 3+ strikes show Long Buildup.", "risk": "Medium", "target_pts": 100, "sl_pts": 50, "rr": "1:2"},
    "SHORT_COVER_SQUEEZE":{"name": "Short Cover Squeeze","description": "Buy when 3+ strikes show Short Covering.", "risk": "High",   "target_pts": 150, "sl_pts": 75, "rr": "1:2"},
    "EMA_9_21":           {"name": "EMA 9/21 Crossover", "description": "EMA9 crosses EMA21 on Index & ATM premiums. Trailing SL auto-adjusts.", "risk": "Medium", "target_pts": 100, "sl_pts": 50, "rr": "1:2"},
}

def check_strategy_signals(symbol, pcr, spot, call_wall, put_wall, activities, chg):
    signals = []
    now_str = datetime.now().strftime("%H:%M:%S")
    if pcr > 1.3:
        signals.append({"strategy":"PCR_REVERSAL","direction":"BUY","entry":spot,
            "target":round(spot+80),"sl":round(spot-40),
            "reason":f"PCR {pcr:.2f} extreme put writing","confidence":"High" if pcr>1.5 else "Medium","time":now_str})
    elif pcr < 0.7:
        signals.append({"strategy":"PCR_REVERSAL","direction":"SELL","entry":spot,
            "target":round(spot-80),"sl":round(spot+40),
            "reason":f"PCR {pcr:.2f} extreme call writing","confidence":"High" if pcr<0.5 else "Medium","time":now_str})
    if call_wall and spot > call_wall-30 and chg > 0:
        signals.append({"strategy":"CALL_WALL_BREAKOUT","direction":"BUY","entry":spot,
            "target":round(spot+120),"sl":round(spot-60),
            "reason":f"Price {spot:.0f} attacking Call Wall {call_wall}","confidence":"Medium","time":now_str})
    if put_wall and spot < put_wall+50 and spot > put_wall-30:
        signals.append({"strategy":"PUT_WALL_BOUNCE","direction":"BUY","entry":spot,
            "target":round(spot+80),"sl":round(spot-40),
            "reason":f"Price {spot:.0f} testing Put Wall {put_wall}","confidence":"High","time":now_str})
    lb_count = sum(1 for a in activities if a["type"]=="LONG_BUILDUP")
    if lb_count >= 2:
        signals.append({"strategy":"LONG_BUILDUP_RIDE","direction":"BUY","entry":spot,
            "target":round(spot+100),"sl":round(spot-50),
            "reason":f"{lb_count} strikes Long Buildup","confidence":"High" if lb_count>=4 else "Medium","time":now_str})
    sc_count = sum(1 for a in activities if a["type"]=="SHORT_COVER")
    if sc_count >= 2:
        signals.append({"strategy":"SHORT_COVER_SQUEEZE","direction":"BUY","entry":spot,
            "target":round(spot+150),"sl":round(spot-75),
            "reason":f"{sc_count} strikes Short Covering","confidence":"High" if sc_count>=3 else "Medium","time":now_str})
    return signals

def auto_execute_paper_trade(symbol, signal, spot):
    global paper_state
    with paper_lock:
        state = paper_state
        existing = [p for p in state["open_positions"]
                    if p["symbol"]==symbol and p["strategy"]==signal["strategy"]]
        if existing: return None
        risk_amount = state["capital"] * 0.02
        sl_pts      = abs(signal["entry"] - signal["sl"])
        qty         = min(max(1, int(risk_amount/max(sl_pts,1))), 75)
        position = {"id":f"PT{int(time.time()*1000)}","symbol":symbol,
            "strategy":signal["strategy"],"direction":signal["direction"],
            "entry":signal["entry"],"target":signal["target"],"sl":signal["sl"],
            "qty":qty,"entry_time":signal["time"],"reason":signal["reason"],
            "confidence":signal["confidence"],"status":"OPEN","pnl":0}
        state["open_positions"].append(position)
        save_paper_state(state)
        return position

def check_exit_paper_trades(symbol, spot):
    global paper_state
    exited = []
    with paper_lock:
        state   = paper_state
        now_str = datetime.now().strftime("%H:%M:%S")
        remaining = []
        for pos in state["open_positions"]:
            if pos["symbol"] != symbol: remaining.append(pos); continue
            hit_target = (pos["direction"]=="BUY" and spot>=pos["target"]) or (pos["direction"]=="SELL" and spot<=pos["target"])
            hit_sl     = (pos["direction"]=="BUY" and spot<=pos["sl"])     or (pos["direction"]=="SELL" and spot>=pos["sl"])
            if hit_target or hit_sl:
                exit_price = pos["target"] if hit_target else pos["sl"]
                pnl = round(((exit_price-pos["entry"]) if pos["direction"]=="BUY" else (pos["entry"]-exit_price))*pos["qty"],2)
                result = "WIN" if pnl>0 else "LOSS"
                trade = {**pos,"exit":exit_price,"exit_time":now_str,
                         "exit_reason":"TARGET" if hit_target else "STOP LOSS",
                         "pnl":pnl,"result":result,"status":"CLOSED"}
                state["trades"].append(trade)
                state["total_pnl"] = round(state["total_pnl"]+pnl,2)
                state["available"] = round(state["available"]+pnl,2)
                state["stats"]["total_trades"] += 1
                if pnl>0: state["stats"]["wins"]+=1; state["stats"]["max_win"]=max(state["stats"]["max_win"],pnl)
                else:     state["stats"]["losses"]+=1; state["stats"]["max_loss"]=min(state["stats"]["max_loss"],pnl)
                today = str(date.today())
                state["daily_pnl"][today] = round(state["daily_pnl"].get(today,0)+pnl,2)
                exited.append(trade)
            else:
                pos["pnl"] = round(((spot-pos["entry"]) if pos["direction"]=="BUY" else (pos["entry"]-spot))*pos["qty"],2)
                remaining.append(pos)
        state["open_positions"] = remaining
        if exited: save_paper_state(state)
    return exited

# ════════════════════════════════════════
#  INSTRUMENTS
# ════════════════════════════════════════
def get_instruments():
    global _instruments_cache, _instruments_date
    today = date.today()
    with _instruments_lock:
        if _instruments_date == today and _instruments_cache:
            return _instruments_cache
        print(f"[{datetime.now():%H:%M:%S}] Loading NFO instruments...")
        t0 = time.time()
        _instruments_cache = kite.instruments("NFO")
        _instruments_date  = today
        print(f"[{datetime.now():%H:%M:%S}] Loaded {len(_instruments_cache)} in {time.time()-t0:.1f}s")
        _rebuild_sym_map()
        return _instruments_cache

def _rebuild_sym_map():
    global _sym_map
    m = {}
    for inst in _instruments_cache:
        otype = inst["instrument_type"]
        if otype not in ("CE","PE"): continue
        key = f"{inst['name']}|{inst['expiry']}"
        m.setdefault(key,{}).setdefault(inst["strike"],{})[otype] = inst["tradingsymbol"]
    with _sym_map_lock:
        _sym_map = m

def get_nearest_expiry(symbol):
    get_instruments()
    dates = sorted({str(i["expiry"]) for i in _instruments_cache if i["name"]==symbol})
    return dates[0] if dates else None

# ════════════════════════════════════════
#  SPOT
# ════════════════════════════════════════
def get_spot(symbol):
    try:
        key = SPOT_KEYS[symbol]
        q   = kite.quote([key])
        d   = q.get(key,{})
        ltp = d.get("last_price",0)
        cls = d.get("ohlc",{}).get("close",0) or ltp or 1
        return {"last_price":ltp,"change":round(ltp-cls,2),
                "open":d.get("ohlc",{}).get("open",0),
                "high":d.get("ohlc",{}).get("high",0),
                "low": d.get("ohlc",{}).get("low",0),"close":cls}
    except Exception as e:
        print(f"Spot error {symbol}: {e}")
        return {"last_price":0,"change":0,"open":0,"high":0,"low":0,"close":0}

# ════════════════════════════════════════
#  OPTION CHAIN — WITH PREMIUMS
# ════════════════════════════════════════
def get_chain_fast(symbol):
    try:
        spot_data = get_spot(symbol)
        spot  = spot_data["last_price"] or (24850 if symbol=="NIFTY" else 52000)
        step  = STEP[symbol]
        atm   = round(spot/step)*step
        relevant = set(atm + i*step for i in range(-STRIKES_N, STRIKES_N+1))

        expiry = get_nearest_expiry(symbol)
        if not expiry:
            return {"chain":[],"expiry":"N/A","spot":spot_data}

        map_key = f"{symbol}|{expiry}"
        with _sym_map_lock:
            strike_map = dict(_sym_map.get(map_key,{}))
        if not strike_map:
            get_instruments()
            with _sym_map_lock:
                strike_map = dict(_sym_map.get(map_key,{}))

        trading_syms = [f"NFO:{tsym}"
                        for s in relevant if s in strike_map
                        for tsym in strike_map[s].values()]
        if not trading_syms:
            return {"chain":[],"expiry":expiry,"spot":spot_data}

        quotes = {}
        for j in range(0,len(trading_syms),200):
            try:
                q = kite.quote(trading_syms[j:j+200])
                quotes.update(q)
            except Exception as e:
                print(f"Quote error: {e}")

        chain = {}
        atm_call_ltp = 0
        atm_put_ltp  = 0

        for s in relevant:
            if s not in strike_map: continue
            chain[s] = {"strike":s,"callOI":0,"putOI":0,"callChg":0,"putChg":0,
                        "callLTP":0,"putLTP":0,
                        "call5minChg":0,"put5minChg":0}
            for otype,tsym in strike_map[s].items():
                q    = quotes.get(f"NFO:{tsym}",{})
                oi   = q.get("oi",0)
                ltp  = q.get("last_price",0)
                oi_h = q.get("oi_day_high",oi)
                oi_l = q.get("oi_day_low",oi)
                chg  = round((oi_h-oi_l)/max(oi,1)*100,2)
                if otype=="CE":
                    chain[s]["callOI"]  = oi
                    chain[s]["callLTP"] = round(ltp,2)
                    chain[s]["callChg"] = chg
                else:
                    chain[s]["putOI"]   = oi
                    chain[s]["putLTP"]  = round(ltp,2)
                    chain[s]["putChg"]  = chg

            if s == atm:
                atm_call_ltp = chain[s]["callLTP"]
                atm_put_ltp  = chain[s]["putLTP"]

        result = sorted(chain.values(), key=lambda x:x["strike"])

        # 1-MINUTE OI SNAPSHOT
        now  = time.time()
        snap = last_snapshot[symbol]
        if not snap or now-last_snap_time[symbol] >= SNAPSHOT_INTERVAL:
            last_snapshot[symbol]  = {d["strike"]:{"c":d["callOI"],"p":d["putOI"]} for d in result}
            last_snap_time[symbol] = now
        else:
            for d in result:
                prev = snap.get(d["strike"],{})
                d["call5minChg"] = d["callOI"]-prev.get("c",d["callOI"])
                d["put5minChg"]  = d["putOI"] -prev.get("p",d["putOI"])

        try:
            exp_disp = datetime.strptime(expiry,"%Y-%m-%d").strftime("%d %b %Y")
        except:
            exp_disp = str(expiry)

        return {"chain":result,"expiry":exp_disp,"spot":spot_data,
                "atm":atm,"atm_call_ltp":atm_call_ltp,"atm_put_ltp":atm_put_ltp}
    except Exception as e:
        print(f"Chain error {symbol}: {e}")
        return {"chain":[],"expiry":"N/A","spot":{}}

# ════════════════════════════════════════
#  OI ACTIVITY — ALL 4 TYPES
# ════════════════════════════════════════
def detect_activity(symbol, chain, spot, prev_spot):
    price_up   = spot > prev_spot if (prev_spot and prev_spot!=spot) else None
    price_down = spot < prev_spot if (prev_spot and prev_spot!=spot) else None
    threshold  = 5000
    now_str    = datetime.now().strftime("%H:%M:%S")
    activities = []

    for d in chain:
        c5,p5     = d["call5minChg"],d["put5minChg"]
        cchg,pchg = d["callChg"],d["putChg"]
        coi,poi   = d["callOI"],d["putOI"]
        new_acts  = []

        if price_up is not None:
            if price_up   and p5 > threshold  and poi > 50000:
                new_acts.append({"type":"LONG_BUILDUP","strike":d["strike"],
                    "label":"Long Buildup","detail":f"Put OI +{sfmt(p5)} | Price Up","time":now_str,"oi_change":p5})
            if price_down and c5 > threshold  and coi > 50000:
                new_acts.append({"type":"SHORT_BUILDUP","strike":d["strike"],
                    "label":"Short Buildup","detail":f"Call OI +{sfmt(c5)} | Price Down","time":now_str,"oi_change":c5})
            if price_down and p5 < -threshold:
                new_acts.append({"type":"LONG_UNWIND","strike":d["strike"],
                    "label":"Long Unwinding","detail":f"Put OI {sfmt(p5)} | Longs Exit","time":now_str,"oi_change":p5})
            if price_up   and c5 < -threshold:
                new_acts.append({"type":"SHORT_COVER","strike":d["strike"],
                    "label":"Short Covering","detail":f"Call OI {sfmt(c5)} | Shorts Cover","time":now_str,"oi_change":c5})

        # Day % fallback
        if pchg > 15 and poi > 200000:
            new_acts.append({"type":"LONG_BUILDUP","strike":d["strike"],
                "label":"Long Buildup","detail":f"Put OI Day +{pchg:.1f}%","time":now_str,"oi_change":poi*pchg/100})
        if cchg > 15 and coi > 200000:
            new_acts.append({"type":"SHORT_BUILDUP","strike":d["strike"],
                "label":"Short Buildup","detail":f"Call OI Day +{cchg:.1f}%","time":now_str,"oi_change":coi*cchg/100})
        if pchg < -10 and poi > 100000:
            new_acts.append({"type":"LONG_UNWIND","strike":d["strike"],
                "label":"Long Unwinding","detail":f"Put OI Day {pchg:.1f}%","time":now_str,"oi_change":abs(poi*pchg/100)})
        if cchg < -10 and coi > 100000:
            new_acts.append({"type":"SHORT_COVER","strike":d["strike"],
                "label":"Short Covering","detail":f"Call OI Day {cchg:.1f}%","time":now_str,"oi_change":abs(coi*cchg/100)})

        activities.extend(new_acts)
        for act in new_acts:
            existing = [a for a in activity_log[symbol]
                        if a["strike"]==act["strike"] and a["type"]==act["type"] and a["time"]==now_str]
            if not existing:
                activity_log[symbol].appendleft({**act,"spot_at_time":round(spot,2)})

    seen, unique = set(), []
    for a in activities:
        k = f"{a['type']}_{a['strike']}"
        if k not in seen:
            seen.add(k); unique.append(a)
    unique.sort(key=lambda x:x.get("oi_change",0), reverse=True)
    return unique[:20]

def calc_max_pain(chain):
    if not chain: return 0
    best,mp = float("inf"),chain[0]["strike"]
    for s in chain:
        loss = sum(d["callOI"]*max(0,s["strike"]-d["strike"])+
                   d["putOI"]*max(0,d["strike"]-s["strike"]) for d in chain)
        if loss<best: best,mp = loss,s["strike"]
    return mp

def gen_signal(pcr,spot,cwall,pwall,chg):
    if not cwall or not pwall: return "WAIT","Insufficient OI data"
    cd,pd = cwall-spot,spot-pwall
    if pcr>1.2 and chg>0 and pd<cd: return "BUY",f"PCR {pcr:.2f} Bullish | Put Wall {pwall:,.0f} holding"
    if pcr<0.8 and chg<0:           return "SELL",f"PCR {pcr:.2f} Bearish | Call Wall {cwall:,.0f} resisting"
    if cd<150:                       return "WAIT",f"Near Call Wall {cwall:,.0f}"
    if pd<150:                       return "WAIT",f"Near Put Wall {pwall:,.0f}"
    if 0.8<=pcr<=1.2:                return "WAIT",f"PCR {pcr:.2f} neutral"
    return "BUY",f"Put writers active | PCR {pcr:.2f}"

def sfmt(n):
    n=n or 0; a=abs(n)
    if a>=1e7: return f"{n/1e7:.1f}Cr"
    if a>=1e5: return f"{n/1e5:.1f}L"
    if a>=1e3: return f"{n/1e3:.0f}K"
    return str(int(n))

# ════════════════════════════════════════
#  AUTH
# ════════════════════════════════════════
def load_token():
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE) as f:
            t=f.read().strip()
            if t:
                kite.set_access_token(t)
                return True
    return False

@app.route("/")
def index():
    if load_token():
        return send_from_directory("static","dashboard.html")
    url = kite.login_url()
    return f"""<html><head><style>
    body{{background:#020d1a;color:#c8e0f0;font-family:'Courier New',mono;
    display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;margin:0;}}
    h2{{color:#00d4ff;}}
    a{{display:inline-block;margin-top:2rem;padding:1rem 2.5rem;background:#00d4ff;color:#020d1a;font-weight:700;text-decoration:none;}}
    </style></head><body>
    <h2>OI TERMINAL v4.0</h2>
    <p style="color:#4a7a9b;">EMA 9/21 Paper Trading | Trailing SL | Option Premiums | 1-Min OI</p>
    <a href="{url}">Login with Zerodha</a></body></html>"""

@app.route("/callback")
def callback():
    rt = request.args.get("request_token")
    if not rt: return "No token. <a href='/'>Try Again</a>",400
    try:
        d = kite.generate_session(rt,api_secret=API_SECRET)
        kite.set_access_token(d["access_token"])
        with open(TOKEN_FILE,"w") as f: f.write(d["access_token"])
        threading.Thread(target=get_instruments, daemon=True).start()
        threading.Thread(target=load_all_historical, kwargs={"delay": 4}, daemon=True).start()
        return redirect("/")
    except Exception as e:
        return f"Login failed: {e} <a href='/'>Try Again</a>",400

# ════════════════════════════════════════
#  MAIN OI API
# ════════════════════════════════════════
@app.route("/api/data/<symbol>")
def api_data(symbol):
    symbol = symbol.upper()
    if symbol not in ("NIFTY","BANKNIFTY"):
        return jsonify({"error":"Invalid"}),400

    now = time.time()
    if now-last_updated[symbol]<10 and oi_cache[symbol]:
        return jsonify(oi_cache[symbol])

    try:
        t0         = time.time()
        chain_data = get_chain_fast(symbol)
        chain      = chain_data.get("chain",[])
        expiry     = chain_data.get("expiry","N/A")
        spot_data  = chain_data.get("spot",{})
        spot       = spot_data.get("last_price",0)
        chg        = spot_data.get("change",0)
        atm        = chain_data.get("atm",0)
        atm_call_ltp = chain_data.get("atm_call_ltp",0)
        atm_put_ltp  = chain_data.get("atm_put_ltp",0)

        prev_spot  = price_history[symbol][-1] if price_history[symbol] else spot
        price_history[symbol].append(spot)

        # ── 5-MIN CANDLE + EMA STRATEGY ──
        update_last_tick(symbol, spot, atm_call_ltp, atm_put_ltp)
        completed_candle = update_5min_candle(symbol, spot, atm_call_ltp, atm_put_ltp)
        if completed_candle:
            update_ema_on_candle_close(symbol, completed_candle)
            if is_strategy_running() and is_in_trade_window():
                sig = check_ema_5min_signal(symbol, completed_candle)
                if sig:
                    auto_execute_ema_trade(symbol, sig)

        # Auto square-off at 3:30 PM
        if is_squareoff_time():
            squareoff_all_ema_positions(symbol)

        # Check exits on every tick (for target/SL)
        check_exit_ema_trades(symbol, atm_call_ltp, atm_put_ltp)
        ema_signals = {}  # kept for compat, no longer used for signals

        total_call = sum(d["callOI"] for d in chain)
        total_put  = sum(d["putOI"]  for d in chain)
        pcr        = round(total_put/max(total_call,1),2)
        pcr_history[symbol].append({"time":datetime.now().strftime("%H:%M"),"pcr":pcr})

        cwall = max(chain,key=lambda x:x["callOI"],default={}).get("strike",0) if chain else 0
        pwall = max(chain,key=lambda x:x["putOI"], default={}).get("strike",0) if chain else 0

        signal,reason  = gen_signal(pcr,spot,cwall,pwall,chg)
        activities     = detect_activity(symbol,chain,spot,prev_spot)
        strat_signals  = check_strategy_signals(symbol,pcr,spot,cwall,pwall,activities,chg)
        for sig in strat_signals:
            auto_execute_paper_trade(symbol,sig,spot)
        check_exit_paper_trades(symbol,spot)

        fm = {
            "long_buildup":  sum(1 for a in activities if a["type"]=="LONG_BUILDUP"),
            "short_buildup": sum(1 for a in activities if a["type"]=="SHORT_BUILDUP"),
            "long_unwind":   sum(1 for a in activities if a["type"]=="LONG_UNWIND"),
            "short_cover":   sum(1 for a in activities if a["type"]=="SHORT_COVER"),
        }

        ema_chart = get_ema_display_data(symbol)

        elapsed = round(time.time()-t0,2)
        print(f"[{datetime.now():%H:%M:%S}] {symbol} {elapsed}s | PCR={pcr} | {signal}")

        result = {
            "status":"ok","symbol":symbol,
            "spot":spot_data,"chain":chain,"expiry":expiry,"pcr":pcr,
            "pcr_history":list(pcr_history[symbol]),
            "call_wall":cwall,"put_wall":pwall,
            "max_pain":calc_max_pain(chain),
            "total_call_oi":total_call,"total_put_oi":total_put,
            "signal":signal,"signal_reason":reason,
            "activities":activities,"five_min_summary":fm,
            "strategy_signals":strat_signals,
            "activity_log":list(activity_log[symbol])[:30],
            "ema_chart":ema_chart,
            "atm":atm,"atm_call_ltp":atm_call_ltp,"atm_put_ltp":atm_put_ltp,
            "fetch_time":elapsed,
            "timestamp":datetime.now().strftime("%H:%M:%S"),
        }
        oi_cache[symbol]     = result
        last_updated[symbol] = now
        return jsonify(result)

    except Exception as e:
        print(f"API error {symbol}: {e}")
        return jsonify({"status":"error","message":str(e)}),500

# ════════════════════════════════════════
#  PAPER TRADING APIs
# ════════════════════════════════════════
@app.route("/api/paper/state")
def api_paper_state():
    with paper_lock:
        return jsonify(paper_state)

@app.route("/api/paper/reset", methods=["POST"])
def api_paper_reset():
    global paper_state
    with paper_lock:
        paper_state = {"capital":100000,"available":100000,"total_pnl":0,
            "trades":[],"open_positions":[],"daily_pnl":{},
            "stats":{"total_trades":0,"wins":0,"losses":0,"max_win":0,"max_loss":0}}
        save_paper_state(paper_state)
    return jsonify({"status":"reset"})

@app.route("/api/paper/close/<position_id>", methods=["POST"])
def api_paper_close(position_id):
    data  = request.json or {}
    spot  = data.get("spot",0)
    with paper_lock:
        state   = paper_state
        now_str = datetime.now().strftime("%H:%M:%S")
        found   = None; remaining = []
        for pos in state["open_positions"]:
            if pos["id"] == position_id: found = pos
            else: remaining.append(pos)
        if not found: return jsonify({"error":"Not found"}),404
        pnl = round(((spot-found["entry"]) if found["direction"]=="BUY" else (found["entry"]-spot))*found["qty"],2)
        trade = {**found,"exit":spot,"exit_time":now_str,"exit_reason":"MANUAL",
                 "pnl":pnl,"result":"WIN" if pnl>0 else "LOSS","status":"CLOSED"}
        state["trades"].append(trade)
        state["total_pnl"] = round(state["total_pnl"]+pnl,2)
        state["available"] = round(state["available"]+pnl,2)
        state["open_positions"] = remaining
        state["stats"]["total_trades"] += 1
        if pnl>0: state["stats"]["wins"]+=1
        else:     state["stats"]["losses"]+=1
        today = str(date.today())
        state["daily_pnl"][today] = round(state["daily_pnl"].get(today,0)+pnl,2)
        save_paper_state(state)
    return jsonify({"status":"closed","pnl":pnl})

@app.route("/api/ema/state")
def api_ema_state():
    with ema_paper_lock:
        s = dict(ema_paper_state)
        s["engine_running"] = is_strategy_running()
        return jsonify(s)

@app.route("/api/ema/start", methods=["POST"])
def api_ema_start():
    global strategy_engine_running
    with strategy_engine_lock:
        strategy_engine_running = True
    print(f"[EMA ENGINE] STARTED at {datetime.now().strftime('%H:%M:%S')}")
    return jsonify({"status": "started", "engine_running": True})

@app.route("/api/ema/stop", methods=["POST"])
def api_ema_stop():
    global strategy_engine_running
    with strategy_engine_lock:
        strategy_engine_running = False
    print(f"[EMA ENGINE] STOPPED at {datetime.now().strftime('%H:%M:%S')}")
    return jsonify({"status": "stopped", "engine_running": False})

@app.route("/api/ema/reset", methods=["POST"])
def api_ema_reset():
    global ema_paper_state
    with ema_paper_lock:
        ema_paper_state = {"capital":100000,"available":100000,"total_pnl":0,
            "trades":[],"open_positions":[],"daily_pnl":{},
            "stats":{"total_trades":0,"wins":0,"losses":0,"max_win":0,"max_loss":0},
            "engine_running": is_strategy_running()}
        save_ema_paper_state(ema_paper_state)
    return jsonify({"status":"reset"})

@app.route("/api/ema/close/<position_id>", methods=["POST"])
def api_ema_close(position_id):
    data = request.json or {}
    # Accept either 'premium' (preferred) or 'spot' for backward compat
    premium = data.get("premium") or data.get("spot", 0)
    with ema_paper_lock:
        state   = ema_paper_state
        now_str = datetime.now().strftime("%H:%M:%S")
        found   = None; remaining = []
        for pos in state["open_positions"]:
            if pos["id"] == position_id: found = pos
            else: remaining.append(pos)
        if not found: return jsonify({"error":"Not found"}),404
        # BUY option: P&L = (exit_premium - entry_premium) * qty
        pnl = round((premium - found["entry"]) * found["qty"], 2)
        result = "WIN" if pnl >= 0 else "LOSS"
        trade = {**found,"exit":premium,"exit_time":now_str,"exit_reason":"MANUAL",
                 "pnl":pnl,"result":result,"status":"CLOSED"}
        state["trades"].append(trade)
        state["total_pnl"] = round(state["total_pnl"]+pnl,2)
        state["available"] = round(state["available"]+pnl,2)
        state["open_positions"] = remaining
        state["stats"]["total_trades"] += 1
        if pnl>=0: state["stats"]["wins"]+=1
        else:     state["stats"]["losses"]+=1
        today = str(date.today())
        state["daily_pnl"][today] = round(state["daily_pnl"].get(today,0)+pnl,2)
        save_ema_paper_state(state)
    return jsonify({"status":"closed","pnl":pnl})

@app.route("/api/candles/<symbol>")
def api_candles(symbol):
    """
    Returns completed 5-min OHLC candles for Index + ATM Call/Put premiums,
    along with EMA9 series and trade entry/exit markers.
    Supports ?tf=5 (default), tf=15, tf=30, tf=60 (aggregated from 5-min candles).
    """
    symbol = symbol.upper()
    if symbol not in ("NIFTY","BANKNIFTY"):
        return jsonify({"error":"Invalid"}),400

    tf = int(request.args.get("tf", 5))   # timeframe in minutes
    if tf not in (1, 5, 15, 30, 60): tf = 5

    with five_min_lock:
        raw_candles = list(five_min_candles[symbol]["completed"])
        cur         = five_min_candles[symbol]["current_bar"]

    # Also include current forming bar for live view
    if cur:
        raw_candles = raw_candles + [dict(cur)]

    # ── Aggregate to requested timeframe ──
    def aggregate(candles, tf_mins):
        if tf_mins == 5:
            return candles
        grouped = {}
        for c in candles:
            try:
                bt = datetime.strptime(c["bar_key"], "%H:%M")
            except:
                continue
            slot_min = (bt.hour * 60 + bt.minute) // tf_mins * tf_mins
            key = f"{slot_min//60:02d}:{slot_min%60:02d}"
            if key not in grouped:
                grouped[key] = {
                    "bar_key":    key,
                    "idx_open":   c["idx_open"],  "idx_high":  c["idx_high"],
                    "idx_low":    c["idx_low"],   "idx_close": c["idx_close"],
                    "call_open":  c["call_open"], "call_high": c["call_high"],
                    "call_low":   c["call_low"],  "call_close":c["call_close"],
                    "put_open":   c["put_open"],  "put_high":  c["put_high"],
                    "put_low":    c["put_low"],   "put_close": c["put_close"],
                }
            else:
                g = grouped[key]
                g["idx_high"]   = max(g["idx_high"],   c["idx_high"])
                g["idx_low"]    = min(g["idx_low"],    c["idx_low"])
                g["idx_close"]  = c["idx_close"]
                g["call_high"]  = max(g["call_high"],  c["call_high"])
                g["call_low"]   = min(g["call_low"],   c["call_low"])
                g["call_close"] = c["call_close"]
                g["put_high"]   = max(g["put_high"],   c["put_high"])
                g["put_low"]    = min(g["put_low"],    c["put_low"])
                g["put_close"]  = c["put_close"]
        return list(grouped.values())

    candles = aggregate(raw_candles, tf)

    # ── EMA9 on aggregated candles ──
    def ema9_series(closes):
        if not closes: return []
        e = [closes[0]]; k = 2/(9+1)
        for p in closes[1:]:
            e.append(p*k + e[-1]*(1-k))
        return [round(x,2) for x in e]

    idx_closes  = [c["idx_close"]  for c in candles]
    call_closes = [c["call_close"] for c in candles]
    put_closes  = [c["put_close"]  for c in candles]

    ema9_idx  = ema9_series(idx_closes)
    ema9_call = ema9_series(call_closes)
    ema9_put  = ema9_series(put_closes)

    # ── Trade markers from EMA paper state ──
    markers = []
    with ema_paper_lock:
        all_trades = list(ema_paper_state.get("trades",[]))
        open_pos   = list(ema_paper_state.get("open_positions",[]))

    for t in all_trades:
        if t.get("symbol") != symbol: continue
        markers.append({
            "type":       "entry",
            "option":     t.get("option","CALL"),
            "bar":        t.get("bar",""),
            "price":      t.get("entry",0),
            "time":       t.get("entry_time",""),
        })
        markers.append({
            "type":       "exit",
            "option":     t.get("option","CALL"),
            "bar":        t.get("bar",""),
            "exit_bar":   t.get("exit_time","")[:5] if t.get("exit_time") else "",
            "price":      t.get("exit",0),
            "exit_reason":t.get("exit_reason",""),
            "pnl":        t.get("pnl",0),
            "result":     t.get("result",""),
            "time":       t.get("exit_time",""),
        })
    for p in open_pos:
        if p.get("symbol") != symbol: continue
        markers.append({
            "type":   "open",
            "option": p.get("option","CALL"),
            "bar":    p.get("bar",""),
            "entry":  p.get("entry",0),
            "target": p.get("target",0),
            "sl":     p.get("sl",0),
            "initial_sl": p.get("initial_sl",0),
            "time":   p.get("entry_time",""),
        })

    return jsonify({
        "symbol":    symbol,
        "tf":        tf,
        "candles":   candles,
        "ema9_idx":  ema9_idx,
        "ema9_call": ema9_call,
        "ema9_put":  ema9_put,
        "markers":   markers,
        "count":     len(candles),
    })

@app.route("/api/history/reload", methods=["POST"])
def api_history_reload():
    """Force reload historical candles for both symbols."""
    global hist_loaded
    hist_loaded = {"NIFTY": False, "BANKNIFTY": False}
    threading.Thread(target=load_all_historical, kwargs={"delay": 0}, daemon=True).start()
    return jsonify({"status": "reloading", "message": "Historical candles reloading..."})

@app.route("/api/history/status")
def api_history_status():
    return jsonify({
        "NIFTY":     {"loaded": hist_loaded.get("NIFTY", False),  "candles": len(five_min_candles["NIFTY"]["completed"])},
        "BANKNIFTY": {"loaded": hist_loaded.get("BANKNIFTY", False), "candles": len(five_min_candles["BANKNIFTY"]["completed"])},
    })

@app.route("/api/paper/strategies")
def api_strategies():
    return jsonify(STRATEGIES)

@app.route("/api/activity_log/<symbol>")
def api_activity_log(symbol):
    symbol = symbol.upper()
    return jsonify(list(activity_log.get(symbol,[])))

@app.route("/api/health")
def health():
    return jsonify({"status":"running","logged_in":os.path.exists(TOKEN_FILE),
                    "instruments":len(_instruments_cache)})

if __name__ == "__main__":
    print("\n"+"="*60)
    print("  OI TERMINAL v5.0 - EMA 5-MIN CANDLE STRATEGY")
    print("  Nifty 50 + Bank Nifty")
    print("="*60)
    print("  Open: http://127.0.0.1:5000")
    print("  NEW: 5-Min Candle EMA strategy (pure candle close)")
    print("  NEW: Start/Stop engine control via dashboard")
    print("  NEW: Time filter 9:45 AM – 3:00 PM")
    print("  NEW: Auto square-off at 3:30 PM")
    print("  NEW: Target +20pts | SL -10pts | Trail 5pts | 10 Lots")
    print("="*60+"\n")
    if load_token():
        threading.Thread(target=get_instruments, daemon=True).start()
        threading.Thread(target=load_all_historical, kwargs={"delay": 3}, daemon=True).start()
    app.run(debug=False,port=5000,threaded=True)
